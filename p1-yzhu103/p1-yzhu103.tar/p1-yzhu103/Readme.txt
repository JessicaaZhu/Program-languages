Group Members:
Na Li: nli19@binghamton.edu
Yuejing Zhu: yzhu103@binghamton.edu

Our code has been tested on bingsuns in yzhu103@bingsun.edu:zyj558/

Execute: 1. Uncompress the A1.tar.gz file
	 2. Enter "make" or "make all"
	 3. Enter ./calc < pro(1-13).txt (.txt files has in our .tar.gz file)

